﻿using System;
namespace CodeChallenge
{
	public static class Constants
	{
        public const string AppID = "deda004c4d0b3f3a82e1890923b3e12e";

        public const string ApiCall = "https://api.openweathermap.org/data/3.0";
    }
}

