﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CodeChallenge.ViewModels
{
    public class BaseViewModel : INotifyPropertyChanged
	{
        public static INavigation Navigation { get; set; }

        public BaseViewModel(INavigation navigation)
		{
            Navigation = navigation;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public virtual async void OnAppearing()
        {
            await Task.Delay(0);
        }
        
        protected void OnPropertyChanged([CallerMemberName] string property = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
    }
}

