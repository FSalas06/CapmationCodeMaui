﻿using System.Collections.ObjectModel;
using CodeChallenge.Models;
using CodeChallenge.Views;

namespace CodeChallenge.ViewModels
{
    public class HomeScreenViewModel : BaseViewModel
	{
        private ObservableCollection<Cities>? _citiesList;
        public ObservableCollection<Cities>? CitiesList
        {
            get => _citiesList;
            set
            {
                _citiesList = value;
                OnPropertyChanged(nameof(CitiesList));
            }
        }

        private Cities? _selectedCity;
        public Cities? SelectedCity
        {
            get => _selectedCity;
            set
            {
                _selectedCity = value;
                OnPropertyChanged(nameof(SelectedCity));
                if (_selectedCity != null)
                {
                    App.Current.MainPage.Navigation.PushAsync(new DetailPage(_selectedCity));
                }
            }
        }

        public HomeScreenViewModel() : base(Navigation)
		{
			CitiesList = new ObservableCollection<Cities>();
        }

        public override void OnAppearing()
        {
            base.OnAppearing();
            CitiesList = new ObservableCollection<Cities>
            {
                new Cities { Nombre = "Bogotá", Latitud = 4.7111, Longitud = -74.0722, Pais = "Colombia" },

                new Cities { Nombre = "Timbío", Latitud = 2.3445, Longitud = -76.6839, Pais = "Colombia" },

                new Cities { Nombre = "Medellín", Latitud = 6.2308, Longitud = -75.5906, Pais = "Colombia" },

                new Cities { Nombre = "Cali", Latitud = 3.4206, Longitud = -76.5222, Pais = "Colombia" },

                new Cities { Nombre = "Barranquilla", Latitud = 10.9833, Longitud = -74.8019, Pais = "Colombia" },

                new Cities { Nombre = "Cartagena", Latitud = 10.4000, Longitud = -75.5000, Pais = "Colombia" },

                new Cities { Nombre = "Bucaramanga", Latitud = 7.1333, Longitud = -73.0000, Pais = "Colombia" },

                new Cities { Nombre = "Palermo", Latitud = 2.8917, Longitud = -75.4375, Pais = "Colombia" },

                new Cities { Nombre = "Cúcuta", Latitud = 7.8942, Longitud = -72.5039, Pais = "Colombia" },

                new Cities { Nombre = "Soledad", Latitud = 10.9167, Longitud = -74.7500, Pais = "Colombia" }
            };
        }
    }
}

