﻿using System;
using System.Diagnostics;
using CodeChallenge.Models;
using CodeChallenge.Services;

namespace CodeChallenge.ViewModels
{
	public class DetailViewModel : BaseViewModel
	{
        private CityDetailService _service;

        private Cities _city;
        public Cities City
		{
			get => _city;
			set
			{
				_city = value;
				OnPropertyChanged();
			}
		}

		private CitiesResponseModel _responseModel;
        public CitiesResponseModel ResponseModel
        {
            get => _responseModel;
            set
            {
                _responseModel = value;
                OnPropertyChanged();
            }
        }

        public DetailViewModel(Cities city) : base(Navigation)
		{
			this.City = city;
			_service = new CityDetailService();
		}

        public async override void OnAppearing()
        {
            base.OnAppearing();
			await LoadDetails();
        }

        private async Task LoadDetails()
        {
			try
			{
				var response = await _service.GetCityInfo(City);
                ResponseModel = response;
            }
			catch(Exception ex)
			{
                Debug.WriteLine($"LoadDetails - ex : {ex.Message}");
            }
        }
    }
}

