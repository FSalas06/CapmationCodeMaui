﻿namespace CodeChallenge.Models;

public class Cities
{
    public string? Nombre { get; set; }
    public double Latitud { get; set; }
    public double Longitud { get; set; }
    public string? Pais { get; set; } 
}
