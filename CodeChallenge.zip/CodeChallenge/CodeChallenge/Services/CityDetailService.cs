﻿using System;
using CodeChallenge.Models;

namespace CodeChallenge.Services
{
	public class CityDetailService : BaseService, ICityDetailService
	{
		public CityDetailService() : base("")
		{
		}

        public async Task<CitiesResponseModel> GetCityInfo(Cities city)
        {
            var result = await GetAsync<CitiesResponseModel>($"onecall?lat={city.Latitud}&lon={city.Longitud}&exclude=minutely,hourly,daily&appid={Constants.AppID}");
            return result;
        }
    }
}

