﻿using System;
using CodeChallenge.Models;

namespace CodeChallenge.Services
{
	public interface ICityDetailService
	{
        Task<CitiesResponseModel> GetCityInfo(Cities city);
	}
}

