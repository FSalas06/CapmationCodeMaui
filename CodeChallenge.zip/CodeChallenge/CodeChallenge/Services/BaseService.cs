﻿using System;
using System.Diagnostics;
using Newtonsoft.Json;

namespace CodeChallenge.Services
{
	public class BaseService
	{
        private string _endpointUrl;
        HttpClient _client;

        private Uri UriBuilder(string endpoint)
        {
            return new Uri(string.Concat(_endpointUrl, endpoint));
        }

        protected BaseService(string endpointPrefix)
        {
            _endpointUrl = $"{Constants.ApiCall}{endpointPrefix}/";

            //var authData = string.Format("{0}:{1}", Constants.Username, Constants.Password);
            //var authHeaderValue = Convert.ToBase64String(Encoding.UTF8.GetBytes(authData));

            _client = new HttpClient
            {
                MaxResponseContentBufferSize = 256000,
                Timeout = TimeSpan.FromSeconds(5)
            };

            //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authHeaderValue);
        }

        protected async Task<T> GetAsync<T>(string endpoint)
        {
            try
            {
                var uri = UriBuilder(endpoint);
                var response = await _client.GetAsync(uri);
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<T>(content);

                return result;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"              ERROR {0}", ex.Message);
                return default;
            }
        }
    }
}

