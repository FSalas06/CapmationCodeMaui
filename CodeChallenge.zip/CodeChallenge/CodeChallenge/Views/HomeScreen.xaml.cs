﻿using CodeChallenge.ViewModels;

namespace CodeChallenge.Views;

public partial class HomeScreen : ContentPage
{
	private HomeScreenViewModel _viewModel;

    public HomeScreen(INavigation navigation)
	{
		InitializeComponent();
		BindingContext = _viewModel = new HomeScreenViewModel();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _viewModel.OnAppearing();
    }
}
