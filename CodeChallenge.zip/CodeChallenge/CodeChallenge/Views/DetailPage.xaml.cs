﻿using CodeChallenge.Models;
using CodeChallenge.ViewModels;

namespace CodeChallenge.Views;

public partial class DetailPage : ContentPage
{
	private DetailViewModel _viewModel;

	public DetailPage(Cities selectedCity)
	{
		InitializeComponent();
		BindingContext = _viewModel = new DetailViewModel(selectedCity);
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _viewModel.OnAppearing();
    }
}
