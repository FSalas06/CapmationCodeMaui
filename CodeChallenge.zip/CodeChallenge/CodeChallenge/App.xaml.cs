﻿using CodeChallenge.Views;

namespace CodeChallenge;

public partial class App : Application
{
    public static INavigation Navigation { get; set; }

    public App()
	{
		InitializeComponent();
        
        MainPage = new NavigationPage(new HomeScreen(Navigation));

        Navigation = Current.MainPage.Navigation;
    }
}

